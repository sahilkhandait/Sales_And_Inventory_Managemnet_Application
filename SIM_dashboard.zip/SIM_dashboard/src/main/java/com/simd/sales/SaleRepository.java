package com.simd.sales;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface SaleRepository extends JpaRepository<Sale, Long> {

    List<Sale> findTop5ByOrderBySaleDateDesc();

    @Query("SELECT SUM(s.totalAmount) FROM Sale s WHERE s.paymentStatus = 'PAID'")
    Double getTotalRevenue();
}